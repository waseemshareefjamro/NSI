document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.getElementById('sidebar');
    const content = document.querySelector('.content');
    const toggleBtn = document.getElementById('toggleBtn');
    const toggleContainer = document.querySelector('.toggle-container');
    let isSidebarVisible = true;

    // Toggle sidebar
    toggleBtn.addEventListener('click', () => {
        isSidebarVisible = !isSidebarVisible;
        if (isSidebarVisible) {
            sidebar.style.transform = 'translateX(0)';
            content.style.marginLeft = window.innerWidth <= 768 ? '70px' : 'var(--sidebar-width)';
            toggleContainer.style.left = window.innerWidth <= 768 ? '1rem' : 'calc(var(--sidebar-width) - 3rem)';
        } else {
            sidebar.style.transform = 'translateX(-100%)';
            content.style.marginLeft = '0';
            toggleContainer.style.left = '1rem';
        }
    });

    // Handle responsive behavior
    window.addEventListener('resize', () => {
        if (isSidebarVisible) {
            content.style.marginLeft = window.innerWidth <= 768 ? '70px' : 'var(--sidebar-width)';
            toggleContainer.style.left = window.innerWidth <= 768 ? '1rem' : 'calc(var(--sidebar-width) - 3rem)';
        }
    });
}); 